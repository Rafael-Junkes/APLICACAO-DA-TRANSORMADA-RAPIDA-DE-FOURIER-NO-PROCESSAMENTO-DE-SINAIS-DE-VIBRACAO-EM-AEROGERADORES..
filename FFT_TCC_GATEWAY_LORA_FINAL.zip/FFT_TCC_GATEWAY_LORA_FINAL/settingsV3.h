// 0K - ISR APPARENTLY WORKING NON COMPROVATED YET!!!!
// JUST RECEIVES CUBECELL MESSAGES FOR INSTANCE!!!!!!!
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/*  Programs for Arduino - Copyright of the author Stuart Robinson - 04/04/20 This
    program is supplied as is, it is up to the user of the program to decide if the
    program is suitable for the intended purpose and free from errors. */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
// *****************  Setup hardware pin definitions here ! **********************
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/*  These are the pin definitions for one of my own boards, a ESP32 shield base
    with my BBF board shield on top. Be sure to change the definitions to match 
    your own setup. Some pins such as DIO2, DIO3, BUZZER may not be in used by 
    this sketch so they do not need to be connected and should be included and be 
    set to -1.                                                                   */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
#define             SCK               9               // SCK on SPI3
#define             MISO              11              // MISO on SPI3 
#define             MOSI              10              // MOSI on SPI3 
#define             NSS               8               // select pin on LoRa device
#define             NRESET            12              // reset pin on LoRa device
#define             RFBUSY            13              // busy line
#define             ONBOARD_LED_PIN   35              // on board LED, high for on
#define             DIO1              14
// DIO1 pin on LoRa device, used for RX and TX done 
#define             SW                -1              
// SW pin on Dorji devices is used to turn RF switch on\off, set to -1 if not used    
#define             BUZZER            -1              
// pin for buzzer, set to -1 if not used 
#define             VCCPOWER          -1              
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
// pin controls power to external devices
// ***************************  Setup LoRa Parameters Here ! **********************
//LoRa Modem Parameters
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
#define             LORA_DEVICE       DEVICE_SX1262   // device in use
const uint32_t      Frequency =       915000000;      
// frequency of transmissions in hertz
const uint32_t      Offset =          0;              
// offset frequency for calibration purposes
const uint8_t       Bandwidth =       LORA_BW_125;    // LoRa bandwidth
const uint8_t       SpreadingFactor = LORA_SF7;       // LoRa spreading factor
const uint8_t       CodeRate =        LORA_CR_4_5;    // LoRa coding rate
const uint8_t       Optimisation =    LDRO_AUTO;      
// low data rate optimisation setting, normally set to auto
const int8_t        TXpower =         19;             // LoRa transmit power in dBm
const uint16_t      packet_delay =    1000;           // mS delay between packets
const uint8_t       LORA_PREAMBLE_LENGTH = 8;         // Same Tx and Rx
const uint8_t       RXBUFFER_SIZE =   150;            // RX buffer size  
#define             LORA_MAC_PRIVATE_SYNCWORD    0x1424    // 0x1A  from 0 to FFFF
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */